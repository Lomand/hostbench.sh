.. aria2 documentation master file, created by
   sphinx-quickstart on Tue Apr 10 21:34:06 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Руководство по Aria2
====================

Содержание:

.. toctree::
   :maxdepth: 3

   aria2c
